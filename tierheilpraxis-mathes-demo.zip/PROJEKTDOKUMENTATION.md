# Projektdokumentation & Design-Spezifikation: Mobile Tierheilpraxis Heike Mathes

> **Zweck dieses Dokuments (Single Source of Truth):**
> Diese Spezifikation dient als verbindliche Referenz für die anschließende Programmierung der Demo-Website. Alle hier festgehaltenen Stammdaten, Texte, Design-Tokens und Anti-Halluzinations-Regeln sind strikt einzuhalten. Es dürfen keine fiktiven Fakten, Preise, Bewertungen oder Leistungen erfunden werden.

---

## 1. Verbindliche Fakten-Datenbank (Stammdaten & Anti-Halluzinations-Regeln)

### 1.1 Verifizierte Praxis-Stammdaten
- **Praxisname:** Mobile Tierheilpraxis Heike Mathes
- **Inhaberin & Berufsbezeichnung:** Heike Mathes – Tierheilpraktikerin
- **Qualifikation:** Prüfung zur Tierheilpraktikerin im Jahr 2003 nach 3-jähriger Ausbildung an der ATM (Akademie für Tiernaturheilkunde) in Bad Bramstedt; seitdem regelmäßige Teilnahme an Fachfortbildungen. (Im Redesign: „Seit über 20 Jahren / seit 2003“ statt des 2019er Texts „16 Jahre“).
- **Praxisform:** Mobile Tierheilpraxis (Hausbesuche zur stressfreien Behandlung von Hunden, Katzen und Kleintieren).
- **Anschrift (gemäß Impressum):** Im Griesböhl 2, 65474 Bischofsheim
- **Finanzamt:** Groß-Gerau
- **Telefon Festnetz:** `06144-337222` (`tel:+496144337222`)
- **Mobil:** `0172-80 10 22 1` (`tel:+491728010221`)
- **E-Mail:** `tierheilpraxis-mathes@gmx.de`
- **Telefon- & Sprechzeiten:**
  - Montag bis Freitag: 8.30 – 19.30 Uhr
  - Samstag: 8.30 – 13.00 Uhr
- **Tätigkeitsraum (Rhein-Main-Gebiet):**
  - Mainz, Oppenheim, Nierstein, Wiesbaden, Hochheim, Flörsheim, Groß-Gerau, Ginsheim-Gustavsburg, Bischofsheim
- **Partner-Link:** `https://www.rb-tierfotografie.de`

### 1.2 Vollständige Original-Inhalte aller Unterseiten (Konsolidierte Referenz)
1. **Über mich (`/ueber-mich/`):**
   - Mobile Tierheilpraxis im Rhein-Main-Gebiet zur stressfreien Behandlung von Hunden, Katzen und Kleintieren zu Hause.
   - Eigene Tiererkrankungen brachten sie zur Homöopathie; 2003 Prüfung an der ATM Bad Bramstedt nach 3-jähriger Ausbildung; regelmäßige Fachfortbildungen.
   - Ausführliche Anamnese und individuelle Behandlungspläne statt pauschal immunsuppressiver Behandlungen (Antibiotika, Cortison wie Prednisolon/Dexamethason, Schmerzmittel).
   - Häufig Einsatz einer Vegatestung (Haaranalyse).
   - Präventionsberatung: artgerechte Ernährung, Gesundheitsvorsorge, Parasiten, Vitalisierung.
   - Ziel: Langes, glückliches Miteinander, Erhalt der Lebensqualität, Gewährleistung der Grundbedürfnisse der Tiere und kritischer Umgang mit Arzneien (auch Impfungen).
2. **Klassische Homöopathie (`/homoeopathie/`):**
   - Reiz- und Regulationstherapie, die mit Einzelmitteln versucht, den Organismus zur Selbstheilung anzuregen.
   - Ausgangsstoffe: Pflanzen, Tiere und ihre Produkte sowie Mineralien, Steine, Erde und Metalle.
3. **Konstitutionstherapie (`/konstitutionstherapie/`):**
   - Tiefgreifende, umstimmende Begleitung bei langwierigen chronischen Beschwerden (sofern ausreichende Reaktionskräfte des Körpers vorhanden sind).
   - Ermittlung des individuellen Konstitutionstyps des Tieres und Auswahl des passenden homöopathischen Einzelmittels.
4. **Homöopathie bei tierklinischen Eingriffen (`/homoeopathie-bei-tierklinischen-eingriffen/`):**
   - Unterstützende Begleitung bei Narkosen, Operationen, Kastrationen, Kaiserschnitten sowie begleitend zu Schmerzmitteln/Antibiotika:
     - Vorbeugung von Komplikationen
     - Prophylaxe von Angst, Stress und Schock
     - Ausleitung von Narkosen und Arzneien
     - Begleitende Linderung von Schmerzen und Juckreiz
     - Unterstützung der Wund- und Knochenheilung
     - Vitalisierung gealterter Patienten
5. **Eingewöhnung und Homöopathie (`/eingewoehnung-und-homoeopathie/`):**
   - Erleichterung der Eingewöhnungsphase bei Welpen, älteren Abgabetieren oder bei einem bevorstehenden Umzug.
6. **Homöopathie bei auffälligem Verhalten (`/homoeopathie-bei-auffaelligem-verhalten/`):**
   - Unsauberkeit
   - Außergewöhnliches Verhalten bei Angst, Aggression, Unsicherheit
   - Übersteigertes Putzverhalten, Leckekzeme
   - Verhaltensveränderungen nach Narkose und Arzneien
   - Reisekrankheiten (z. B. Speicheln, Erbrechen, Harn- und Kotabsatz bei Autofahrten)
   - Nach einem Schockerlebnis oder nach schlechter Haltung
7. **Horvi-Enzymtherapie (`/horvi-enzymtherapie/`):**
   - Naturheilkundliche Enzymtherapie als sanfte, regulierende Begleitung bei verschiedenen Beschwerdebildern (HWG-konform formuliert).
8. **Haaranalyse / Vegatestung (`/haaranalyse/`):**
   - Empfehlenswert bei langwierigen, komplexen Beschwerden (z. B. rund um Nervensystem, Bewegungsapparat/Lahmheiten, Allergien, Erbrechen, Durchfall) sowie als präventiver Gesundheitscheck bei jungen und älteren Tieren.
9. **Parasiten (`/parasiten/`):**
   - Naturheilkundliche Beratung bei Befall und zur Prophylaxe gegen Zecken, Milben, Flöhe sowie Würmer, Giardien und Kokzidien.
   - Aufklärung über Risiken und Nebenwirkungen chemischer Wurmkuren, Tabletten, Spot-on-Präparate, Antiparasitenhalsbänder und -hundebetten.
10. **Ernährung (`/ernaehrung/`):**
    - Beratung zu artgerechter, ausgewogener, natürlicher Nahrung und Erstellung individueller Ernährungspläne für Hunde und Katzen (Prävention und Begleitung z. B. bei Allergien, Nieren- oder Bauchspeicheldrüsenbelastungen).
    - Stärkung des Immunsystems durch natürliche Ergänzungsmittel.
    - Detaillierter Futter-Check inklusive aller Snacks, Leckerchen und Kauknochen.

---

## 2. Design-Tokens („Warm Botanical Minimalism“)

```css
:root {
  /* Colors */
  --bg-primary: #FAF8F5;        /* Warm Alabaster / Leinen */
  --bg-secondary: #F2ECE4;      /* Soft Oat / Sand */
  --surface-card: #FFFFFF;      /* Pure Cream Card */
  --primary-sage: #2C4A3E;      /* Deep Botanical Sage */
  --primary-sage-hover: #21382F;
  --primary-mist: #E3ECE7;      /* Eucalyptus Mist */
  --accent-terracotta: #B86B43; /* Warm Terracotta */
  --text-primary: #1E2522;      /* Forest Charcoal */
  --text-secondary: #56615B;    /* Muted Olive Grey */
  --border-stone: #E4DDD3;      /* Warm Stone Hairline */

  /* Typography */
  --font-serif: 'Lora', Georgia, serif;
  --font-sans: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
}
```

---

## 3. Geplante Bild-Dateinamen (Katalog)
1. `hero-tierheilpraxis.jpg` (4:5 oder 1:1 – Hund/Katze entspannt im warmen Wohn- oder Naturumfeld)
2. `ueber-mich-praxis.jpg` (4:5 oder 4:3 – Porträt / Hausbesuchs-Situation / Anamnese-Stillleben)
3. `therapie-homoeopathie.jpg` (16:10 – Braunglasfläschchen, Globuli & Heilpflanzen)
4. `therapie-ernaehrung.jpg` (16:10 – Keramiknapf mit natürlicher Nahrung)
5. `therapie-katze-ruhe.jpg` (16:10 – Entspannte Katze im Tageslicht für Haaranalyse/Verhalten)
6. `hausbesuch-rhein-main.jpg` (16:9, optional – Hund in der Natur im Rhein-Main-Gebiet)
